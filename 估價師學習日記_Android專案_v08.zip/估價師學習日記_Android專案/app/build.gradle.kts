plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "tw.studyjournal.appraiser"
    compileSdk = 35

    defaultConfig {
        applicationId = "tw.studyjournal.appraiser"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.8"
    }
}
