估價師學習日記 v0.8｜Android 測試專案

這是將 appraiser_study_journal_v08.html 包進 Android WebView 的測試版專案。
保留原 HTML 介面與功能；資料仍由網頁的 localStorage 保存在此 App 的本機資料區。
本專案關閉 Android 系統層級的自動備份（allowBackup=false），不加入雲端、帳號或匯入/匯出功能。

重要限制：
- 這份檔案是 Android Studio 專案，不是已簽署、可直接點擊安裝的 APK。
- 目前執行環境沒有 Android SDK/Gradle，無法在這裡實際編譯 APK，也未能在實機上驗證。
- 刪除 App 或清除 App 資料可能會刪除學習紀錄；因為你選擇不使用備份，請先以測試資料測試。

如何產生測試 APK（需要一台電腦）：
1. 在電腦安裝 Android Studio（官方網站下載）。
2. 解壓縮整個「估價師學習日記_Android專案」資料夾。
3. 在 Android Studio 選擇 Open，開啟這個資料夾。
4. 等待 Gradle Sync 完成；若提示安裝 Android SDK 35，依提示安裝。
5. 選單 Build > Build Bundle(s) / APK(s) > Build APK(s)。
6. 完成後按通知中的 locate，找到 app-debug.apk。
7. 將 APK 傳到 Android 手機，允許該來源安裝 APK，再點擊安裝。

首次測試建議：
- 先新增一筆測試紀錄，關閉 App 再重開，確認紀錄仍在。
- 測試新增、修改、刪除紀錄與統計是否同步。
- 先不要放入重要學習資料，直到確認運作正常。

專案版本：0.8
應用程式名稱：估價師學習日記
套件 ID：tw.studyjournal.appraiser
